// Select color input
// Select size input

// When size is submitted by the user, call makeGrid()
(function(document){
  'use strict';


const elements = {
  //taking details of color,pixels,height,width and putting in single element
  colorPicker: document.querySelector('#colorPicker'),
  gridView: document.querySelector('#pixelCanvas'),
  columns: document.querySelector('#inputWidth'),
  rows: document.querySelector('#inputHeight')
};


const listen= function(){
  document.querySelector('#sizePicker').addEventListener('submit',makeGrid,false);  //builds event listener of id sizePicker
  elements.gridView.addEventListener('click',getGridColor);            //set color to pixels
};


function makeGrid(event) {
  event.preventDefault();
  const gridSize = setGridSize();


  elements.gridView.innerHTML = '';  //clears the pixelCanvas

  for (let r= 0; r< gridSize.N ; r++) {
    let totalRows=elements.gridView.insertRow(r);
      for(let c=0; c< gridSize.M; c++){
      totalRows.insertCell(c);
   }
}
}

function setGridSize(){             //to gather gridSize
  let N = elements.rows.value;    //no. of rows
  let M = elements.columns.value;     //no.of columns
  return{
    M: parseInt(M),
    N: parseInt(N)
  }
}

function getGridColor(event){
  let color= elements.colorPicker.value;
  event.target.setAttribute('style','background-color:'+color);
}
listen();
}(document));
